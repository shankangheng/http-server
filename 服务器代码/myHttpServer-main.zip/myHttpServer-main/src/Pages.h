#ifndef __PAGES__
#define __PAGES__

extern const char SERVER_NAME[];
extern const char NOT_FOUND_PAGE[];
extern const char FORBIDDEN_PAGE[];

#endif